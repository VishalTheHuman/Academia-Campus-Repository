from django.shortcuts import render, redirect
from django.contrib import messages
from .models import File
from .forms import FileModelForm

def file_list(request):
    files = File.objects.all()
    return render(request, 'file_manager/file_list.html', {'files': files})

from django.shortcuts import render, redirect
from django.contrib import messages
from .models import File
from .forms import FileModelForm

# views.py
from django.shortcuts import render, redirect
from django.contrib import messages
from .models import File
from .forms import FileModelForm

def upload_file(request):
    if request.method == 'POST':
        form = FileModelForm(request.POST, request.FILES)
        if form.is_valid():
            instance = form.save(commit=False)
            instance.owner = request.user
            instance.email = request.user.email
            instance.save()
            messages.success(request, 'File uploaded successfully!')
            form = FileModelForm() 
    else:
        form = FileModelForm()

    return render(request, 'teacherhome.html', {'form': form})


def delete_file(request, file_id):
    file = File.objects.get(pk=file_id)
    file.delete()
    messages.success(request, 'File deleted successfully!')
    return redirect('file_list')

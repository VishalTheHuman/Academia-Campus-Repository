from django.urls import path
from .views import file_list, upload_file, delete_file

urlpatterns = [
    path('file_list/', file_list, name='file_list'),
    path('upload_file-file/', upload_file, name='upload_file'),
    path('delete_file/<int:file_id>/', delete_file, name='delete_file'),
]

from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from login.models import UserProfile

@login_required
def studentHome(request):
    try:
        profile = UserProfile.objects.get(email=request.user.email)
    except UserProfile.DoesNotExist:
        profile = None
        print('UserProfile not found for user:', request.user.email)

    context = {
        'profile': profile,
    }
    return render(request, 'studenthome.html', context)

from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from login.models import UserProfile

@login_required
def teacherHome(request):
    try:
        profile = UserProfile.objects.get(email=request.user.email)
    except UserProfile.DoesNotExist:
        profile = None
        print('UserProfile not found for user:', request.user.email)
        return render(request,'404.html')

    context = {
        'profile': profile,
    }
    return render(request, 'teacherhome.html', context)